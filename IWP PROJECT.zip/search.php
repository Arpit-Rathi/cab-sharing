<?php include "includes/header.php";?>
<div class="jumbotron">
	<div class="container">
		<div class="row">
			<div class="col-lg-5">
				<div class="row" id="left-top">
					<form action="" method="post">
						<input type="search" placeholder="SOURCE" id="source" name="source">
						<input type="search" placeholder="DESTINATION" id="destination" name="destination">
						<input type="submit" name="submit" style="visibility: hidden;" id="go">
					</form>
				</div>
				<div class="row" id="left-bottom" style="background-color: green;">
					<div id="map"></div>
					
					    
				</div>
			</div>
			<div class="col-lg-7" id="right" style="line-height: 6px;">
				<h2 style="text-align: center;">RESULTS</h2>
			<?php if (isset($_POST['submit'])){
				include_once 'includes/dbh_inc.php';
				      $sql = "SELECT * FROM trips WHERE source='$_POST[source]' OR destination='$_POST[destination]'";
				      $result = mysqli_query($con, $sql);

				      if (mysqli_num_rows($result) > 0) {
				          // output data of each row
				          while($row = mysqli_fetch_assoc($result)) {
				              if(isset($_SESSION['uid'])){
				              	echo "<div class='result' id=$row[trip_id]>
				        <div class='middle' style='float: left;'>
				          <p>From $row[source]</p>
				          <p>to $row[destination]</p>
				          <p>on $row[date1]</p>
				          <p>at $row[time1] hrs</p>
				        </div>
				        <div class='right' style='float: left';>
				          <h3>₹ $row[price]</h3>
				          <p>per seat</p>
				          <p>$row[seats] SEATS LEFT</p>
				        </div>
				        <div class='left' style='float: right;'>
				          <p style='line-height: 20px;'>CONTACT $row[phn]</p>
				        </div>
				      </div>";
				  }
				  else{
				  	        	echo "<div class='result' id=$row[trip_id]>
				  	  <div class='middle' style='float: left;'>
				  	    <p>From $row[source]</p>
				  	    <p>to $row[destination]</p>
				  	    <p>on $row[date1]</p>
				  	    <p>at $row[time1] hrs</p>
				  	  </div>
				  	  <div class='right' style='float: left';>
				  	    <h3>₹ $row[price]</h3>
				  	    <p>per seat</p>
				  	    <p>$row[seats] SEATS LEFT</p>
				  	  </div>
				  	  <div class='left' style='float: right;'>
				  	  <span style='line-height: 20px;'>SIGN IN TO BOOK</span>
				  	  </div>
				  	</div>";
				  }
				          }
				      } else {
				          echo "<hr><h3 style='text-align: center;'>0 results</h3>";
				      }
			}
			else{
				echo "<hr><h3 style='text-align: center;'>search for trips</h3>";
			}
			?>
				
			</div>

		</div>
	</div>
</div>
</div>
<script>
	console.log("done");
	var map;
	var LatLng={lat:12.91,lng: 79.13};
	var mapOptions={
		center: LatLng,
		zoom: 10,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var directionsService = new google.maps.DirectionsService();
	var input1=document.getElementById("source");
	var input2=document.getElementById("destination");
	var options={
		types: ["(cities)"]
	};
	var autoComplete1=new google.maps.places.Autocomplete(input1,options);
	var autoComplete2=new google.maps.places.Autocomplete(input2,options);
	google.maps.event.addDomListener(window,'load',initialize);
	function initialize(){
		directionsDisplay = new google.maps.DirectionsRenderer();
		map=new google.maps.Map(document.getElementById("map"),mapOptions);
		directionsDisplay.setMap(map);
	}
	google.maps.event.addListener(autoComplete1, 'place_changed', calcRoute);
	google.maps.event.addListener(autoComplete2, 'place_changed', calcRoute);

	// Calculate Route:  
	function calcRoute() {
	    var start = $('#source').val();
	    console.log(start);
	    var end = $('#destination').val();
	    var request = {
	        origin:start, 
	        destination:end,
	        travelMode: google.maps.DirectionsTravelMode.DRIVING,
	        unitSystem: google.maps.UnitSystem.IMPERIAL,
	        durationInTraffic: false,   
	        avoidHighways: false,   
	        avoidTolls: false,
	    };
	    if(start && end){
	        directionsService.route(request, function(response, status) {
	            if (status == google.maps.DirectionsStatus.OK) {
	                directionsDisplay.setDirections(response);
	                document.querySelector("#go").style.visibility="visible";
	            }else{ 
	                initialize();
	            }
	        });
	    }
	}
</script>
</body>
</html>