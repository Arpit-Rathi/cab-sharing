<?php 
if(!(isset($_POST['id']))){
	header("Location: myTrip.php");
}
include "includes/header.php";
include_once "includes/dbh_inc.php";
$sql="SELECT * FROM trips WHERE trip_id='$_POST[id]';";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
?>
	<form action="includes/updateTripValue.php" method="post">
		<input type='text' name='id' style='background-color: steelblue; display: none;'  value="<?php echo $row['trip_id'];?>">
	<table>
		<tr>
			<th colspan="2" style="text-align: center; background-color: #393939;">EDIT YOUR TRIP DETAILS</th>
		</tr>
		<tr>
			<td>TRIP ID</td>
			<td><?php echo $row['trip_id']; ?></td>
		</tr>
		<tr>
			<td>SOURCE</td>
			<td><?php echo $row['source']; ?></td>
		</tr>
		<tr>
			<td>DESTINATION</td>
			<td><?php echo $row['destination']; ?></td>
		</tr>
		<tr>
			<td>DATE</td>
			<td><input type="date" value="<?php echo $row['date1'];?>" name="date1"
				></td>
		</tr>
		<tr>
			<td>TIME</td>
			<td><input type="time" value="<?php echo $row['time1']; ?>" name="time1"
				></td>
		</tr>
		<tr>
			<td>PRICE PER SEAT</td>
			<td><input type="number" value="<?php echo $row['price']; ?>" name="price"
				></td>
		</tr>
		<tr>
			<td>SEATS LEFT</td>
			<td><input type="number" value="<?php echo $row['seats']; ?>" name="seats"
				></td>
		</tr>
		<tr>
			<th colspan="2"><input type="submit"></th>
		</tr>
	</table>
</form>