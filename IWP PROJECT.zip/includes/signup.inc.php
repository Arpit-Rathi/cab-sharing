<?php
    include_once 'dbh_inc.php';
	session_start();    
	$_SESSION['error']="SIGNUP ERROR";
	$first=mysqli_real_escape_string($con,$_POST['fname']);
	$last=mysqli_real_escape_string($con,$_POST['lname']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$uid=mysqli_real_escape_string($con,$_POST['uname']);
	$phone=mysqli_real_escape_string($con,$_POST['phone']);
	$pwd=mysqli_real_escape_string($con,$_POST['password']);
	$repwd=mysqli_real_escape_string($con,$_POST['repwd']);
	$valid=1;
	//error-handlers
	if (!preg_match("/^[a-zA-Z ]*$/",$first)){
		$valid=0;
	}
	if (!preg_match("/^[a-zA-Z ]*$/",$last)){
		$valid=0;
	}
	if (!preg_match("/^[0-9]{10}$/",$phone)){
		$valid=0;
	}
	if (!(strpos($email,"@vitstudent.ac.in"))){
		$valid=0;
	}
	if (!($pwd==$repwd)){
		$valid=0;
	}
	//check for empty fields
	if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd)){
		header("Location: signupConf.php?signup=empty");
		exit();
	}
	else if($valid===0){
		header("Location: signupConf.php?error=WrongInput");
		exit();
	}
	else{
		$_SESSION['error']="SIGNUP SUCCESS";
		$m=uniqid();
		$uac=$m.$uid;
		$sql="INSERT INTO user (first_name,last_name,phn_number,email,username,password,activation_key) VALUES('$first','$last','$phone','$email','$uid','$pwd','$uac');";
		$result=mysqli_query($con,$sql);

        $to = $email;
        $subject = 'ACCOUNT ACTIVATION UAC CODE';
        $from = 'CARPOOL';
 
        // To send HTML mail, the Content-type header must be set
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
        // Create email headers
        $headers .= 'From: '.$from."\r\n".'Reply-To: '.$from."\r\n" .'X-Mailer: PHP/' . phpversion();
        // Compose a simple HTML email message
        $message = '<html><body>';
        $message .= '<p style="color:#f40;"COPY THE UAC AND PASTE IT IN THE FIELD PROVIDED</p>';
        $message .= '<p style="color:#080;font-size:18px;">UAC : </p>';
        $message .= '</body></html>'.$uac;
 
        // Sending email
        mail($to, $subject, $message, $headers);
		header("Location: signupConf.php?signup=success");
		exit();			
	}
?>