<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>CARSHARE</title>
</head>
<body style="background-color: #1F2833">
<div style="width: 60%; height: 350px; border-radius: 10px; margin: 100px auto; background-color: #CFC6C7; font-size: 50px; text-align: center; box-shadow: 6px 6px 10px #0B0C10;">
	<h5 style="padding: 0px; margin: 0px; background-color: black; color: white; letter-spacing: 2px; font-family: arial; font-weight: 200;"><?php echo $_SESSION['error'];?></h5>
	<span style="font-size: 18px; text-align: left">
	<?php 
	if($_SESSION['error']=="SIGNUP ERROR"){
	echo '<ul>
	POSSIBLE ERRORS :
	<li>Firstname and lastname must contain only letters</li>
	<li>Phone number must be of ten digits</li>
	<li>Password must match with the re-typed password</li>
	<li>The email id that you entered must be your <b><u>vit gmail id</u></b></li>
	</ul>
	</span><span style="font-size: 20px;">GO TO
	<a href="../index.php">HOME PAGE</a></span>';
	}
	else{
		echo '<p style="text-align: center;">Thankyou for registering on our website.</p><hr><p style="text-align: center;">Check your VIT mail spam folder to get the UAC code.</p><span style="font-size: 20px;">Activate your account
	<a href="../signUpConform.php">ACTIVATE</a></span>';
	}
	?>
</div>
</body>
</html>