<?php
	include_once "dbh_inc.php";
	if(isset($_POST['uname']) && isset($_POST['uac']))
	{
		$sql="UPDATE user SET activation=1 WHERE activation_key='$_POST[uac]' and username='$_POST[uname]'";
		$results = mysqli_query($con, $sql);
		//check if query is successful
		if(!$results){
		    echo '<div class=" alert alert-danger">There was an error! The account could not be activated.!</div><hr><a href="../index.php">GO BACK TO HOMEPAGE.</a>';      
		}
		else{
		    header("Location: ../index.php");
		}
	}
	else
	{
		echo "ERROR";
	}
?>