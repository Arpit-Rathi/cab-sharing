<?php
session_start();

if(isset($_POST['submit'])){
	include 'dbh_inc.php';
	$uid=mysqli_real_escape_string($con,$_POST['username']);
	$pwd=mysqli_real_escape_string($con,$_POST['password']);
	if(empty($uid) || empty($pwd)){
		header("Location: ../index.php?login=empty");
		exit();
	}
	else{
		$sql="SELECT * FROM user WHERE username='$uid' and password='$pwd'";
		$result=mysqli_query($con,$sql);
		$resultCheck=mysqli_num_rows($result);
		if($resultCheck<0){
			header("Location: ../index.php?login=error");
			exit();
		}
		else{
			if($row=mysqli_fetch_assoc($result)){
				if(!($pwd===$row['password'])){
					Location("Location: ../index.php?login=passwordError");
					exit();
				}
				elseif($row['activation']==0){
		        header("Location: ../signUpConform.php");
		        exit();
		        }
					elseif($pwd===$row['password']){
					$_SESSION['uid']=$row['u_id'];
					$_SESSION['ufirst']=$row['first_name'];
					$_SESSION['ulast']=$row['last_name'];
					$_SESSION['uemail']=$row['phn_number'];
					$_SESSION['uuid']=$row['username'];
					$_SESSSION['phn']=$row['phn_number'];
					header("Location: ../index.php?login=success");
					exit();
				}
			}
				else{
					header("Location: ../index.php?error=WrongPassword");
					exit();
				}
		}
	}
}
else{
	header("Location: ../index.php?login=error1");
}
?>