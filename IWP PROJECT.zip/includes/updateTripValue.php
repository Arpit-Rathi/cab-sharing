<?php
session_start();
if(isset($_SESSION['uid'])){
	include_once "dbh_inc.php";
	if(isset($_POST['date1']) && isset($_POST['time1']) && isset($_POST['price']) && isset($_POST['seats']))
	{
		$sql="UPDATE trips SET seats=$_POST[seats], date1='$_POST[date1]', time1='$_POST[time1]', price=$_POST[price] WHERE trip_id=$_POST[id]";
		$results = mysqli_query($con, $sql);
		//check if query is successful
		if(!$results){
		    echo '<div class=" alert alert-danger">There was an error! The trip could not be changed to database!</div><hr><a href="../myTrip.php">GO BACK TO YOUR TRIPS</a>';      
		}
		else{
		    header("Location: ../myTrip.php");
		}
	}
	else
	{
		echo "ERROR";
	}
}
?>