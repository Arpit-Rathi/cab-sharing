<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>CAR SHARE</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAI3ymQnZbL0pbVKaQh1F8gPMgyCCLg6os&libraries=places"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
  	<i class="fa fa-cab" style="font-size:24px; color: white;"></i>&nbsp;&nbsp;
    <a class="navbar-brand" href="#">CARPOOL</a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active" style="border-right: 1px solid gray;">
        <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
      </li>
      <?php 
      if(isset($_SESSION['uid'])){
        echo '<li class="nav-item">
        <a class="nav-link" href="myTrip.php">My Trips</a>
      </li>';
      } ?>
      <li class="nav-item" style="border-right: 1px solid gray;">
        <a class="nav-link" href="search.php">Search For a trip</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="help.php">About Us</a>
      </li>
    </ul>
    <?php 
      if(isset($_SESSION['uid'])){
        echo '
        <div class="btn-group">
          <div class="btn-group dropdown" role="group">
            <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="sr-only">Toggle Dropleft</span>
            </button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="profileInfo.php">profile</a>
                  <a class="dropdown-item" href="includes/deleteAccount.php">delete account</a>
                  <div class="dropdown-divider"></div>
                   <a class="dropdown-item" href="includes/logout.inc.php">LOGOUT</a>
            </div>
          </div>
          <button type="button" class="btn btn-secondary" style="letter-spacing: 2px;">
            '.$_SESSION['ufirst'].' '.$_SESSION['ulast'].'
          </button>
        </div>';
      } 
      else{
    echo '<form class="form-inline my-2 my-lg-0" action="includes/login.inc.php" method="post">
      <input class="form-control mr-sm-2" type="text" placeholder="username" name="username">
      <input class="form-control mr-sm-2" type="password" placeholder="password" name="password">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="submit">LOGIN</button>
    </form>';
  }
  ?>
  </div>
</nav>