<?php
session_start();
include_once "dbh_inc.php";
$sql="DELETE FROM user WHERE u_id=$_SESSION[uid]";
$sql1="DELETE FROM trips WHERE user_id=$_SESSION[uid]";
$results = mysqli_query($con, $sql);
//check if query is successful
if(!$results){
    echo '<div class=" alert alert-danger">There was an error! The account cold not be deactivated.</div><hr><a href="../index.php">GO BACK TO YOUR DASHBOARD</a>';      
}
else{
	$results1 = mysqli_query($con, $sql1);
    header("Location: logout.inc.php");
}
?>