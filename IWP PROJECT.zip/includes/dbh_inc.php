<?php
error_reporting(1);
$dbServername="localhost";
$dbUsername="id640602_root";
$dbPassword="qwertyui";
$dbName="id640602_dbh";

$con=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

?>