<?php include 'includes/header.php'?>
<div class="container">
    <h1>ACCOUNT CONFIRMATION</h1>
    <hr>
<form action="includes/activateAccount.php" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">USERNAME</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your username" name="uname">
    <small id="emailHelp" class="form-text text-muted">The one which you provided during the signup process.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">UNIQUE AUTHENTICATION CODE (UAC)</label>
    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Copy the UAC sent to your mail(check your spam folder also)" name="uac">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>