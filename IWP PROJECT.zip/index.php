<?php include "includes/header.php";?>
<div id="myNav" class="overlay">

  <!-- Button to close the overlay navigation -->
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  <!-- Overlay content -->
  <div class="overlay-content">
    <form id="regForm" action="includes/signup.inc.php" method="post">

    <h1>Register</h1>

    <!-- One "tab" for each step in the form: -->
    <div class="tab">Personal Info
      <p><input type="text" placeholder="First name..." oninput="this.className = ''" name="fname" id="fname"></p>
      <p><input type="text" placeholder="Last name..." oninput="this.className = ''" name="lname" id="lname"></p>
    </div>

    <div class="tab">Contact Info
      <p><input type="email" placeholder="VIT E-mail..." oninput="this.className = ''" name="email"></p>
      <p><input type="text" placeholder="Phone..." oninput="this.className = ''" name="phone" id="phone"></p>
    </div>


    <div class="tab">Login Info
      <p><input type="text" placeholder="Username..." oninput="this.className = ''" name="uname"></p>
      <p><input type="password" placeholder="Password..." oninput="this.className = ''" name="password" id="password"></p>
      <p><input type="password" placeholder="Re-Type Password..." oninput="this.className = ''" name="repwd" id="repwd"></p>
    </div>

    <div style="overflow:auto;">
      <div style="float:right;">
        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
        <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
      </div>
    </div>

    <!-- Circles which indicates the steps of the form: -->
    <div style="text-align:center;margin-top:40px;">
      <span class="step"></span>
      <span class="step"></span>
      <span class="step"></span>
    </div>

    </form>
  </div>

</div>


<div class="jumbotron">
  <div class="container" id="banner">
  <h1 class="display-4" style="text-shadow: 2px 2px rgba(20,20,20,0.2);">C A R P O O L</h1>
  <p class="lead"><strong>THE ONLINE CAB POOL SEARCH PLATFORM</strong></p>
  <hr class="my-4">
  <span style="background-color: rgba(10,10,10,0.4); padding: 10px;">now find the best cab to share for a journey</span>
  <?php 
      if(!(isset($_SESSION['uid']))){
  echo '<p class="lead">
    <span class="btn btn-success btn-lg" href="#" role="button" onclick="openNav();">SIGNUP  <i style="font-size:24px" class="fa">&#xf090;</i></span>
  </p>';
}
  ?>
</div>
</div>
<script type="text/javascript">
	/* Open when someone clicks on the span element */
	function openNav() {
	    document.getElementById("myNav").style.width = "100%";
	}

	/* Close when someone clicks on the "x" symbol inside the overlay */
	function closeNav() {
	    document.getElementById("myNav").style.width = "0%";
	}
	var currentTab = 0; // Current tab is set to be the first tab (0)
	showTab(currentTab); // Display the current tab

	function showTab(n) {
	  // This function will display the specified tab of the form ...
	  var x = document.getElementsByClassName("tab");
	  x[n].style.display = "block";
	  // ... and fix the Previous/Next buttons:
	  if (n == 0) {
	    document.getElementById("prevBtn").style.display = "none";
	  } else {
	    document.getElementById("prevBtn").style.display = "inline";
	  }
	  if (n == (x.length - 1)) {
	    document.getElementById("nextBtn").innerHTML = "Submit";
	  } else {
	    document.getElementById("nextBtn").innerHTML = "Next";
	  }
	  // ... and run a function that displays the correct step indicator:
	  fixStepIndicator(n)
	}

	function nextPrev(n) {
	  // This function will figure out which tab to display
	  var x = document.getElementsByClassName("tab");
	  // Exit the function if any field in the current tab is invalid:
	  if (n == 1 && !validateForm()) return false;
	  // Hide the current tab:
	  x[currentTab].style.display = "none";
	  // Increase or decrease the current tab by 1:
	  currentTab = currentTab + n;
	  // if you have reached the end of the form... :
	  if (currentTab >= x.length) {
	    //...the form gets submitted:
	    document.getElementById("regForm").submit();
	    return false;
	  }
	  // Otherwise, display the correct tab:
	  showTab(currentTab);
	}

	function validateForm() {
	  // This function deals with validation of the form fields
	  var x, y, i, valid = true;
	  x = document.getElementsByClassName("tab");
	  y = x[currentTab].getElementsByTagName("input");
	  console.log(y.length);
	  // A loop that checks every input field in the current tab:
	  for (i = 0; i < y.length; i++) {
	    // If a field is empty...
	    if (y[i].value == "") {
	      // add an "invalid" class to the field:
	      y[i].className += " invalid";
	      // and set the current valid status to false:
	      valid = false;
	    }
	  }
	  // If the valid status is true, mark the step as finished and valid:
	  if (valid) {
	    document.getElementsByClassName("step")[currentTab].className += " finish";
	  }
	  return valid; // return the valid status
	}

	function fixStepIndicator(n) {
	  // This function removes the "active" class of all steps...
	  var i, x = document.getElementsByClassName("step");
	  for (i = 0; i < x.length; i++) {
	    x[i].className = x[i].className.replace(" active", "");
	  }
	  //... and adds the "active" class to the current step:
	  x[n].className += " active";
	}
</script>
</body>
</html>