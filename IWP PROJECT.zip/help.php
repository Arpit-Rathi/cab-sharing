<?php include "includes/header.php";?>
<div class="jumbotron">
  <div class="container" id="banner">
  	<h2 style="letter-spacing: 2px; border-bottom: 2px solid green; width: 27%; margin: 0 auto;">INSTRUCTIONS</h2>
  	<ol style="font-size: 28px; list-style-type: 1; letter-spacing: 2px; color: white; background-color: rgba(0,0,0,0.6); margin-top: 10px; border-radius: 21px 20px 80px 10px;">
  		<li>This website helps to find cabtrips.</li>
  		<li>Add new trips that you want to share with others.</li>
  		<li>Search for trips even without registering on the website.</li>
  		<li>To get the contact details, you must have a CARPOOL account.</li>
  		<li>Even edit the trips if you have made a mistake.</li>
  		<p>So hurry up and have a CARPOOL account..!!</p>
  	</ol>
</div>
</div>
</body>
</html>