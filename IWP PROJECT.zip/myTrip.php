<?php include "includes/header.php";?>

  <div class="jumbotron">
	  <form method="post" action="includes/addTrip.inc.php">
      <div class="modal fade" id="addtripModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	 <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">NEW TRIP</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        
	        	<div id="result"></div>
                          
                          <!--Google Map-->
                          <div id="map"></div>
                          
                        <div class="form-group">
                            <label for="source" class="sr-only">Source:</label>
                            <input type="text" name="source" id="source" placeholder="Source" autocomplete="on" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="destination" class="sr-only">Destination:</label>
                            <input type="text" name="destination" id="destination" placeholder="Destination" class="form-control" autocomplete="on">
                        </div>
                        <div class="form-group">
                            <label for="price" class="sr-only">Price per seat:</label>
                            <input type="number" name="price" id="price" placeholder="Sharing price per seat" class="form-control">
                        </div> 
                        <div class="form-group">
                            <label for="seatsavailable" class="sr-only">Seats available:</label>
                            <input type="number" name="seats" id="seatsavailable" placeholder="number of persons to share" class="form-control" max=6 min=1>
                        </div>
                        <div class="form-group">
                            <label for="date"  class="sr-only">Date of journey: </label>    
                            <input name="date" type="date" id="date" placeholder="Date"  class="form-control">
                        </div>  
                        <div class="form-group time">
                            <label for="time" class="sr-only">Time of journey: </label>    
                            <input type="time" name="time" id="time" placeholder="Time"  class="form-control">
                        </div>
                        <input type="text" style="display: none;" id="a" name="departureLatitude">
                        <input type="text" style="display: none;" id="b" name="departureLongitude">
                        <input type="text" style="display: none;" id="c" name="destinationLatitude">
                        <input type="text" style="display: none;" id="d" name="destinationLongitude">
                     
          <script>
            console.log("done");
            var map;
            var LatLng={lat:12.91,lng: 79.13};
            var mapOptions={
              center: LatLng,
              zoom: 10,
              mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            var directionsService = new google.maps.DirectionsService();
            var input1=document.getElementById("source");
            console.log(input1);
            var input2=document.getElementById("destination");
            var options={
              types: ["(cities)"]
            };
            var autoComplete1=new google.maps.places.Autocomplete(input1,options);
            var autoComplete2=new google.maps.places.Autocomplete(input2,options);
            google.maps.event.addDomListener(window,'load',initialize);
            function initialize(){
              directionsDisplay = new google.maps.DirectionsRenderer();
              map=new google.maps.Map(document.getElementById("map"),mapOptions);
              directionsDisplay.setMap(map);
            }
            google.maps.event.addListener(autoComplete1, 'place_changed', calcRoute);
            google.maps.event.addListener(autoComplete2, 'place_changed', calcRoute);

            // Calculate Route:  
            function calcRoute() {
                var start = $('#source').val();
                console.log(start);
                var end = $('#destination').val();
                var request = {
                    origin:start, 
                    destination:end,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING,
                    unitSystem: google.maps.UnitSystem.IMPERIAL,
                    durationInTraffic: false,   
                    avoidHighways: false,   
                    avoidTolls: false,
                };
                if(start && end){
                    directionsService.route(request, function(response, status) {
                        if (status == google.maps.DirectionsStatus.OK) {
                            directionsDisplay.setDirections(response);
                            getAddTripDepartureCoordinates();
                            getAddTripDestinationCoordinates();
                        }else{ 
                            initialize();
                        }
                    });
                }
            }
            // Fix Map    
            $('#addtripModal').on('shown.bs.modal', function () {
                google.maps.event.trigger(map, "resize");
                });
            
            var departureLongitude = 0, departureLatitude = 0, destinationLongitude = 0, destinationLatitude = 0;
            var data; var trip;

            
            //create a geocoder object to use the geocode
            var geocoder = new google.maps.Geocoder();
            function getAddTripDepartureCoordinates(){
                geocoder.geocode(
                    {
                        'address' : document.getElementById("source").value
                    },
                    function(results, status){
                        if(status == google.maps.GeocoderStatus.OK){
                            departureLongitude = results[0].geometry.location.lng();
                            departureLatitude = results[0].geometry.location.lat();
                            document.getElementById("a").value=departureLongitude;
                            document.getElementById("b").value=departureLatitude;
                        }else{
                            console.log("some error");
                        }

                    }
                );
            }

            function getAddTripDestinationCoordinates(){
                geocoder.geocode(
                    {
                        'address' : document.getElementById("destination").value
                    },
                    function(results, status){
                        if(status == google.maps.GeocoderStatus.OK){
                            destinationLongitude = results[0].geometry.location.lng();
                            destinationLatitude = results[0].geometry.location.lat();
                            document.getElementById("c").value=destinationLatitude;
                            document.getElementById("d").value=destinationLongitude;
                        }else{
                          console.log("Some Error");
                        }

                    }
                );

            }
          </script>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">ADD</button>
	      </div>
	    </div>
	  </div>
	</div> 
  </form>






  

  <div class="container">
  	<div class="col-lg-10 col-lg-offset-1" id="right" style="line-height: 6px; margin: 0 auto;">
  		<h2 style="text-align: center;">My Trips</h2>
  		<button class="btn btn-primary my-2 my-sm-0" type="submit" data-toggle="modal" data-target="#addtripModal" data-whatever="@mdo">Add Trip <big>+</big></button>
  		<br><hr>
      <?php

      include_once 'includes/dbh_inc.php';
      $sql = "SELECT * FROM trips WHERE user_id='$_SESSION[uid]'";
      $result = mysqli_query($con, $sql);

      if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
              echo "<div class='result' id=$row[trip_id]>
        <div class='middle' style='float: left;'>
          <p>From $row[source]</p>
          <p>to $row[destination]</p>
          <p>on $row[date1]</p>
          <p>at $row[time1] hrs</p>
        </div>
        <div class='right' style='float: left';>
          <h3>₹ $row[price]</h3>
          <p>per seat</p>
          <p>$row[seats] SEATS LEFT</p>
        </div>
        <div class='left' style='float: right;'>
          <form action='editTrip.php' method='post'><input type='text' name='id' value=$row[trip_id] style='display:none;'><button class='btn btn-primary my-2 my-sm-0' type='submit'>E d i t</button></form>
        </div>
      </div>";
          }
      } else {
          echo '<span style="background-color: rgba(10,10,10,0.2);">
          <h3 style="text-align: center; ">There are currently no trips in your dashboard.</h3>
          <br>
          <h4 style="text-align: center;">Click on <button class="btn btn-primary my-2 my-sm-0" type="submit" data-toggle="modal" data-target="#addtripModal" data-whatever="@mdo">Add Trip <big>+</big></button> to add one.</h4>
          </span>';
      }


      

      ?>
      
  	</div>
</div>
</div>
<script>
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

today = yyyy+'-'+mm+'-'+dd;
document.getElementById("date").setAttribute("min", today);
</script>
</body>
<html>