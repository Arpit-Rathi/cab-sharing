<?php 
include "includes/header.php";
include_once "includes/dbh_inc.php";
$sql="SELECT * FROM user WHERE u_id='$_SESSION[uid]';";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
?>
	<table id="table">
		<tr style=" border-bottom: 1px solid black;">
			<th colspan="2">PROFILE INFORMATION</th>
		</tr>
		<tr style=" border-bottom: 1px solid black;">
			<td style="width: 60%;">FIRST NAME</td>
			<td><?php echo $row['first_name']; ?></td>
		</tr>
		<tr style=" border-bottom: 1px solid black;">
			<td style="width: 60%;">LAST NAME</td>
			<td><?php echo $row['last_name']; ?></td>
		</tr>
		<tr style=" border-bottom: 1px solid black;">
			<td style="width: 60%;">PHONE NUMBER</td>
			<td><?php echo $row['phn_number']; ?></td>
		</tr>
		<tr style=" border-bottom: 1px solid black;">
			<td style="width: 60%;">EMAIL</td>
			<td><?php echo $row['email']; ?></td>
		</tr>
		<tr style=" border-bottom: 1px solid black;">
			<td style="width: 60%;">USERNAME</td>
			<td><?php echo $row['username']; ?></td>
		</tr>
	</table>